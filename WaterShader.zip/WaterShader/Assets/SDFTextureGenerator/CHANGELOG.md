1.0.1 (2021/05/23)
------------------

* Refactoring and minor compute shader optimisation (group thread size).


1.0.0 (2021/05/19)
------------------

* Initial public version.
